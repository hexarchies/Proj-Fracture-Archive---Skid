import express from "express";
import { getEnv } from "./utils";
import logger from "./utils/logger";
import RouteHandler from "./handlers/RouteHandler";
import Database from "./database/DB";
import helmet from "helmet";
import WebSocket from "ws";
import crypto from "crypto";
import XMPP from "./xmpp/XMPP";

const app = express();
const PORT = 3551;

(async () => {
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use(helmet());

  app.listen(PORT, () => {
    logger.log(`Server running on port ${PORT}`, "Server", "blueBright");
  });

  app.use((req, res, next) => {
    if (req.originalUrl.toLowerCase().startsWith("/fortnite/api/cloudstorage/user/") && req.method == "PUT") {
        req.rawBody = "";
        req.setEncoding("latin1");

        req.on("data", (chunk) => req.rawBody += chunk);
        req.on("end", () => next());
    }
    else return next();
  })
  await RouteHandler.initializeRoutes(app);
  app.use((req, res, next) => {
    //next();
    var XEpicErrorName = "errors.com.epicgames.common.not_found";
    var XEpicErrorCode = 1004;

    res.set({
        'X-Epic-Error-Name': XEpicErrorName,
        'X-Epic-Error-Code': XEpicErrorCode
    });

    res.status(404);
    res.json({
        "errorCode": XEpicErrorName,
        "errorMessage": "Sorry the resource you were trying to find could not be found",
        "numericErrorCode": XEpicErrorCode,
        "originatingService": "any",
        "intent": "prod"
    });

    console.log("404: " + req.path);
  });
  await Database.connect();
  new XMPP();
})();
