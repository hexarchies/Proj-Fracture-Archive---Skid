import mongoose from "mongoose";
import logger from "../utils/logger";

const DB_URL = "mongodb+srv://plush:helloW1%40@fake-eon.jqm3pl1.mongodb.net/?retryWrites=true&w=majority";

export default {
  async connect(): Promise<void> {
    mongoose.set("strictQuery", true);
    // console.log(DB_URL);
    mongoose
      .connect(DB_URL)
      .then(() => {
        logger.log("Connected to MongoDB", "Database", "magentaBright");
      })
      .catch((error) => {
        logger.error(`MongoDB Connection Error: ${error.message}`, "Database");
        throw error; // Re-throw the error to propagate it if needed.
      });
  },
};
