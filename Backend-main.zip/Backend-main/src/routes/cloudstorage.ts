import { Router } from "express";
import fs from "fs";
import path from "path";
import logger from "../utils/logger";
import crypto from 'crypto';

export default function initRoute(router: Router): void {
  router.get("/fortnite/api/cloudstorage/system", (req, res) => {
    res.setHeader("content-type", "application/json");
    const dir = path.join(__dirname, "..", "resources", "cloudstorage");
    var files: Object[] = [];

    fs.readdirSync(dir).forEach(name => {
      if (name.toLowerCase().endsWith(".ini")) {
        const ParsedFile = fs.readFileSync(path.join(dir, name), 'utf-8');
        const ParsedStats = fs.statSync(path.join(dir, name));

        files.push({
          "uniqueFilename": name,
          "filename": name,
          "hash": crypto.createHash('sha1').update(ParsedFile).digest('hex'),
          "hash256": crypto.createHash('sha256').update(ParsedFile).digest('hex'),
          "length": ParsedFile.length,
          "contentType": "application/octet-stream",
          "uploaded": ParsedStats.mtime,
          "storageType": "S3",
          "storageIds": {},
          "doNotCache": true
        });
      }
    });
    res.json(files);
    res.status(200);
  });

  router.get("/fortnite/api/cloudstorage/system/config", (req, res) => {
    res.setHeader("content-type", "application/json");
    res.json({
      lastUpdated: "2022-11-15T18:17:16.342Z",
      disableV2: true,
      isAuthenticated: true,
      enumerateFilesPath: "/api/cloudstorage/system",
      enableMigration: false,
      enableWrites: false,
      epicAppName: "Live",
      transports: {
        McpProxyTransport: {
          name: "McpProxyTransport",
          type: "ProxyStreamingFile",
          appName: "fortnite",
          isEnabled: false,
          isRequired: true,
          isPrimary: true,
          timeoutSeconds: 30,
          priority: 10,
        },
        McpSignatoryTransport: {
          name: "McpSignatoryTransport",
          type: "ProxySignatory",
          appName: "fortnite",
          isEnabled: false,
          isRequired: false,
          isPrimary: false,
          timeoutSeconds: 30,
          priority: 20,
        },
        DssDirectTransport: {
          name: "DssDirectTransport",
          type: "DirectDss",
          appName: "fortnite",
          isEnabled: true,
          isRequired: false,
          isPrimary: false,
          timeoutSeconds: 30,
          priority: 30,
        },
      },
    });
    res.status(200);
  });

  router.all("/fortnite/api/cloudstorage/system/:file", (req, res) => {
    const file = req.params.file;
    try {
      res.sendFile(
        path.join(__dirname, "..", "resources", "cloudstorage", file)
      );
      res.status(200);
    } catch (err) {
      console.log(err);
      res.status(200);
    }
  });

  /*router.get(
    "/fortnite/api/cloudstorage/user/:accountId/:filename",
    (req, res) => {
      console.log("get cloudstorage wrong");
      try {
        const filePath = path.join(
          __dirname,
          "..",
          "resources",
          "cloudstorage",
          req.params.filename
        );
        const fileStream = fs.readFileSync(filePath);

        res.contentType("application/octet-stream");
        res.setHeader(
          "Content-Disposition",
          `attachment; filename="${req.params.filename}"`
        );
        res.send(fileStream);
      } catch (error) {
        let err = error as Error;
        console.error(err.message, "CloudStorage");
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  );*/

  router.get("/fortnite/api/cloudstorage/user/:id/:file", (req, res) => {
    console.log("get cloudstorage right");
    res.contentType("application/octet-stream");
    const filePath = path.join(
      __dirname,
      "..",
      "..",
      "ClientSettings",
      `ClientSettings-${req.params.id}.sav`
    );

    try {
      const fileStream = fs.readFileSync(filePath);
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="${req.params.file}"`
      );
      res.send(fileStream);
    } catch (error) {
      let err = error as Error;
      console.error(err.message, "CloudStorage");
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

  router.put("/fortnite/api/cloudstorage/user/:id/:file", (req, res) => {
    res.contentType("application/octet-stream");
    console.log("put cloudstorage");

    if (
      req.headers["content-length"] &&
      parseInt(req.headers["content-length"] as string) >= 400000
    ) {
      return res.status(403).send("Request Entity is Too Large");
    }

    try {
      const body = req.rawBody.toString("latin1");
      const folderPath = path.join(__dirname, "..", "..", "ClientSettings");

      if (!fs.existsSync(folderPath)) {
        try {
          fs.mkdirSync(folderPath, { recursive: true });
        } catch (error) {
          let err = error as Error;
          console.error(err.message, "CloudStorage");
          return res.status(500).json({ error: "Internal Server Error" });
        }
      }

      const filePath = path.join(
        folderPath,
        `ClientSettings-${req.params.id}.sav`
      );
      fs.writeFileSync(filePath, body, "latin1");
      res.status(204).send();
    } catch (error) {
      let err = error as Error;
      console.error(err.message, "CloudStorage");
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

  router.get("/fortnite/api/cloudstorage/user/:id", (req, res) => {
    res.contentType("application/json");
    console.log("get cloudstorage 2");

    try {
      const filePath = path.join(
        __dirname,
        "..",
        "..",
        "ClientSettings",
        `ClientSettings-${req.params.id}.sav`
      );
      let fileContent;
      try {
        fileContent = fs.readFileSync(filePath, "utf8");
      } catch {
        let defaultSettings = fs.readFileSync(path.join(__dirname, "..", "resources", "cloudstorage", "ClientSettings.sav"), "utf8");
        fs.writeFileSync(filePath, defaultSettings, "latin1");
        fileContent = fs.readFileSync(filePath, "utf8");
      }
      const fileInfo = fs.statSync(filePath);

      res.json([
        {
          uniqueFilename: "ClientSettings.Sav",
          filename: "ClientSettings.Sav",
          hash: crypto.createHash('sha1').update(fileContent).digest('hex'),
          hash256:
            crypto.createHash('sha256').update(fileContent).digest('hex'),
          length: fileContent.length,
          contentType: "application/octet-stream",
          uploaded: fileInfo.mtime,
          storageType: "S3",
          storageIds: {},
          accountId: req.params.id,
          doNotCache: false,
        },
      ]);
    } catch (error) {
      let err = error as Error;
      console.error(err.message, "CloudStorage");
      res.status(500).json({ error: "Internal Server Error" });
    }
  });
}
