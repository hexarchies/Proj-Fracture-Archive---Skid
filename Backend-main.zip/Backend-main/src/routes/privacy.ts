import { Router } from "express";
import fs from 'fs';

export default function initRoute(router: Router): void {
    router.get("/fortnite/api/game/v2/privacy/account/:accountId", async (req, res) => {
        let privacy;
        try {
            privacy = fs.readFileSync(`./data/privacy-${req.params.accountId}.json`) as Object as { accountId: any };
        } catch {
            let d = {
                accountId: req.params.accountId,
                optOutOfPublicLeaderboards: false
            };
            fs.writeFileSync(`./data/privacy-${req.params.accountId}.json`, JSON.stringify(d, null, 2));
            privacy = d;
        }
        privacy['accountId'] = req.params.accountId;
    
        res.json(privacy);
    })
    
    router.post("/fortnite/api/game/v2/privacy/account/:accountId", async (req, res) => {
        const privacy = fs.readFileSync(`./data/privacy-${req.params.accountId}.json`) as Object as { accountId: any, optOutOfPublicLeaderboards: boolean };
        privacy.accountId = req.params.accountId;
        privacy.optOutOfPublicLeaderboards = req.body.optOutOfPublicLeaderboards;
    
        fs.writeFileSync(`./data/privacy-${req.params.accountId}.json`, JSON.stringify(privacy, null, 2));
    
        res.json(privacy);
        res.end();
    })
}
