import { Router } from "express";
import logger from "../utils/logger";
import Account, { IAccount } from "../database/models/Account";
import User from "../database/models/User";
import { sendErrorResponse } from "./oauth";
import Athena from "../resources/mcp/MCPAthena";
import CommonCore from "../resources/mcp/MCPCommonCore";
import {
  EquipBattleRoyaleCustomization,
  SetCosmeticLockerSlot,
} from "../resources/mcp/MCPEquipBattleRoyaleCustomization";
import MCPCommonCore from "../resources/mcp/MCPCommonCore";
import catalog from "../resources/storefront/catalog.json";
import profile from "../../athena.json";
import axios from "axios";
import { getEnv } from "../utils";
import { IProfile } from "../resources/mcp/interfaces/ProfileInterface";
import quests from "../resources/quests/Season12Quests.json";
import { v4 as generateUUID } from "uuid";
import { AccountItem } from "../resources/quests/IQuests";

export default function initRoute(router: Router): void {
  router.post(
    "/fortnite/api/game/v2/profile/:accountId/*/MarkItemSeen",
    async (req, res) => {
      // TODO
      return res.json({}).status(201);
    }
  );

  router.post(
    [
      "/fortnite/api/game/v2/profile/:accountId/*/QueryProfile",
      "/fortnite/api/game/v2/profile/:accountId/*/SetHardcoreModifier",
    ],
    async (req, res) => {
      try {
        const { rvn, profileId } = req.query;
        const { accountId } = req.params;

        const userAgent = req.headers["user-agent"];
        const account = await User.findOne({ accountId }).lean();

        let season = userAgent?.split("-")[1]?.split(".")[0] || 2;

        if (!account) {
          return res.status(404).json({ error: "Account not found." });
        }

        if (!rvn) {
          return {};
        }

        if (profileId === "athena" || profileId === "profile0") {
          return res.json(
            await Athena(
              accountId,
              profileId,
              false,
              season,
              req.query.rvn || -1
            )
          );
        } else if (
          profileId === "common_core" ||
          profileId === "common_public"
        ) {
          return res.json(await CommonCore(accountId, profileId));
        } else {
          const responseData = {
            profileRevision: (rvn as any) + 1,
            profileId,
            profileChangesBaseRevision: 1,
            profileChanges: [],
            profileCommandRevision: 1,
            serverTime: new Date(),
            responseVersion: 1,
          };
          res.json(responseData);
        }
      } catch (error) {
        let err = error as Error;
        logger.error(`Error updating profile: ${err.message}`, "MCP");
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  );

  router.post(
    [
      "/fortnite/api/game/v2/profile/:accountId/*/EquipBattleRoyaleCustomization",
      "/fortnite/api/game/v2/profile/:accountId/*/SetCosmeticLockerSlot",
    ],
    async (req, res) => {
      console.log("gasp 1.0")
      try {
        const { accountId } = req.params;
        const {
          profileId,
          slotName,
          itemToSlot,
          indexWithinSlot,
          category,
          variantUpdates,
          rvn,
          slotIndex,
        } = req.body;

        if (req.body.slotName !== undefined) {
          console.log("gasp 2.0, " + JSON.stringify(req.body));
          return res.json(
            await EquipBattleRoyaleCustomization(
              accountId,
              profileId,
              slotName,
              itemToSlot,
              indexWithinSlot,
              variantUpdates,
              rvn
            )
          );
        } else {
          console.log("gasp 3.0, " + JSON.stringify(req.body));
          return res.json(
            await SetCosmeticLockerSlot(
              accountId,
              profileId,
              category,
              itemToSlot,
              slotIndex,
              variantUpdates,
              rvn as any
            )
          );
        }
      } catch (error) {
        let err = error as Error;
        logger.error(`Error updating profile: ${err.message}`, "MCP");
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  );
  router.post(
    "/fortnite/api/game/v2/profile/:accountId/client/PurchaseCatalogEntry",
    async (req, res) => {
      console.log("Buy");
      try {
        const { accountId } = req.params;
        const user = await User.findOne({ accountId });
        const account = await Account.findOne({ accountId });
        const profileId = req.query.profileId as string;
        const currency = req.query.currency as string;

        const userAgent = req.headers["user-agent"];
        const season = (userAgent?.split("-")[1]?.split(".")[0] ||
          "2") as string;

        if (!user) {
          return res.status(404).json({ error: "User does not exist" });
        } else if (!account) {
          return res.status(404).json({ error: "Account does not exist" });
        }

        const baseRevision = account.profilerevision + 1;
        let selectedItem: any = null;
        let multiUpdates: any[] = [
          {
            profileRevision: account.RVN || 0,
            profileId: "athena",
            profileChangesBaseRevision: account.BaseRevision || 0,
            profileChanges: [],
            profileCommandRevision:
              profile.profileChanges.find((data) => data)?.profile
                .commandRevision || 0,
          },
        ];
        let notifications: any[] = [];
        let profileChanges: any[] = [];
        let givenItemsData: any[] = [];
        let updatedProfile;

        if (!account.items) {
          return (account.items = {});
        }

        
        const storefronts = catalog.storefronts as any[];
        console.log(storefronts);
        const entries = [].concat.apply([], storefronts.map(m => m["catalogEntries"]) as any[]);
        console.log(entries);
        const offerId = entries.map(p => p["offerId"]);
        console.log(offerId);

        // Shop Purchasing attempt 5
        let AccountData = {
          _id: "RANDOM",
          Update: "",
          Created: new Date().toISOString(),
          updated: new Date().toISOString(),
          rvn: 0,
          wipeNumber: 1,
          accountId: "",
          profileId,
          version: "no_version",
          items: {},
          stats: {
            attributes: {},
          },
          commandRevision: 5,
        };

        AccountData["items"] = await Athena(accountId, profileId, true, season);
        AccountData["stats"]["attributes"] = await Athena(
          accountId,
          profileId,
          true,
          season
        ).then((data: any) => {
          console.log(JSON.parse(JSON.stringify(data)));
          return data.profileChanges.find(
            (profileChangesData: any) => (profileChangesData.stats ?? {attributes: {}}).attributes
          );
        });

        // get the latest shop
        const response = await axios
          .get(
            `http://127.0.0.1:3551/fortnite/api/storefront/v2/catalog`
          )
          .then((data) => data.data);
        console.log(response);

        let catalogPurchaseId: any = null;

        for (const storefront of response.storefronts) {
          for (const entries of storefront.catalogEntries) {
            console.log(entries.offerId, offerId);
            if (entries.offerId === offerId) {
              console.log(catalogPurchaseId + entries);
              catalogPurchaseId = entries;
            }
          }
        }

        for (const storefront of catalogPurchaseId.itemGrants) {
          return givenItemsData.push({
            itemType: storefront.templateId,
            itemGuid: storefront.templateId,
            itemProfile: AccountData,
            quantity: storefront.quantity,
          });
        }

        const responseData = {
          profileRevision: (req.query.rvn as any) + 1 || 1,
          profileId,
          profileChangesBaseRevision: 1,
          profileChanges: [
            {
              changeType: "fullProfileUpdate",
            },
          ],
          notifications: [
            {
              type: "CatalogPurchase",
              primary: true,
              lootResult: {
                items: givenItemsData,
              },
            },
          ],
          profileCommandRevision: 1,
          serverTime: new Date(),
          responseVersion: 1,
        };

        return res.status(204).json(responseData);
      } catch (error) {
        const err = error as Error;
        logger.error(`Error processing purchase: ${err.message} stk: ${err.stack}`, "MCP");
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  );

  router.post(
    "/fortnite/api/game/v2/profile/:accountId/client/ClaimMfaEnabled",
    async (req, res) => {
      const { accountId } = req.params;
      const { profileId } = req.query;
      const account: IAccount | null = await Account.findOne({
        accountId,
      }).lean();

      const commonCore = await CommonCore(accountId, profileId as string).then(
        async (data) => {
          return data.profileChanges.find(
            (profileChangesData: any) =>
              profileChangesData.profile.stats.attributes
          );
        }
      );

      if (commonCore.mfa_enabled)
        return sendErrorResponse(
          res,
          "OperationForbidden",
          "MFA is already enabled on your account."
        );
    }
  );

  router.post(
    "/fortnite/api/game/v2/profile/:accountId/client/ExchangeGameCurrencyForBattlePassOffer",
    async (req, res) => {
      console.log("Ex VBucks for BP");
      try {
        const { offerItemIdList } = req.body;
        const { profileId, rvn } = req.query;

        const responseData = {
          profileRevision: (rvn as any) + 1 || 1,
          profileId,
          profileChangesBaseRevision: 1,
          profileChanges: [
            {
              changeType: "fullProfileUpdate",
              profile: {},
            },
          ],
          profileCommandRevision: 1,
          serverTime: new Date(),
          responseVersion: 1,
        };
      } catch (error) {
        let err = error as Error;
        logger.error(
          `ExchangeGameCurrencyForBattlePassOffer: ${err.message}`,
          "MCP"
        );
        return res.status(500).json({ error: "Internal Server Error" });
      }
    }
  );

  router.post(
    "/fortnite/api/game/v2/profile/:accountId/client/GiftCatalogEntry",
    async (req, res) => {
      try {
        const {
          receiverAccountIds,
          giftWrapTemplateId,
          personalMessage,
          offerId,
        } = req.body;
        const { rvn, profileId } = req.query;
        const { accountId } = req.params;

        console.log(receiverAccountIds[0]);

        const friends: IAccount | null = await Account.findOne({
          accountId: receiverAccountIds[0],
        }).lean();

        if (!friends) {
          return res.status(404).json({ error: "User not found." });
        }

        let allGifts: any[] = [];

        // get latest shop
        const response = await axios
          .get(
            `http://127.0.0.1:3551/fortnite/api/storefront/v2/catalog`
          )
          .then((data) => data.data);

        let catalogPurchaseId: any = null;

        for (const storefront of response.storefronts) {
          for (const entries of storefront.catalogEntries) {
            if (entries.offerId === offerId) {
              catalogPurchaseId = entries;
            }
          }
        }

        // Debug log
        console.log(catalogPurchaseId["itemGrants"]);

        for (const userGifts of friends.gifts) {
          return allGifts.push({
            giftbox: userGifts.giftbox || "GiftBox:gb_default",
            personsend: accountId,
            giftedAt: userGifts.giftedAt,
            message: userGifts.message || "We hope you enjoy playing on PlooshFN :)",
            itemGuid: userGifts.itemGuid,
            items: userGifts.items,
          });
        }

        allGifts.push({
          giftbox: giftWrapTemplateId || "GiftBox:gb_default",
          personsend: accountId,
          message: personalMessage || "We hope you enjoy playing on PlooshFN :)",
          itemGuid: offerId,
          items: catalogPurchaseId["itemGrants"],
        });

        // Debug logs
        console.log(allGifts);

        await Account.updateOne(
          { accountId: receiverAccountIds[0] },
          { ["gifts"]: allGifts }
        );

        const responseData = {
          profileRevision: (rvn as any) + 1,
          profileId,
          profileChangesBaseRevision: 1,
          profileChanges: [],
          profileCommandRevision: 1,
          serverTime: new Date(),
          responseVersion: 1,
        };

        res.json(responseData);
      } catch (error) {
        let err = error as Error;
        logger.error(
          `Error getting catalogEntry for gift: ${err.message}`,
          "MCP"
        );
        return res.status(500).json({ error: "Internal Server Error" });
      }
    }
  );

  router.post(
    "/fortnite/api/game/v2/profile/:accountId/client/RemoveGiftBox",
    async (req, res) => {
      try {
        const rvn = req.query.rvn;
        const accountId = req.params.accountId;
        const profileId = req.query.profileId;
        const userAgent = req.headers["user-agent"];
        let season = userAgent?.split("-")[1]?.split(".")[0] || 2;
        const account = await Account.findOne({ accountId });
        const giftBoxItemId = req.body.giftBoxItemId;
        const giftBoxItemIds = req.body.giftBoxItemIds;

        if (!account) {
          return res.json({
            error: "Oops! This account seems to have vanished.",
          });
        }

        const applyProfileChanges: any[] = [];
        const queryRevision = rvn || "-1";
        const baseRevision = account.BaseRevision || 0;

        if (typeof req.body.giftBoxItemId === "string") {
          if (!account.gifts[req.body.giftBoxItemId]) {
            return sendErrorResponse(
              res,
              "InvalidGift",
              `Sorry, your buddy doesn't have this gift.`
            );
          }

          if (
            !account.gifts[req.body.giftBoxItemId].templateId.startsWith(
              "GiftBox:"
            )
          ) {
            return sendErrorResponse(
              res,
              "NotAGiftBox",
              `The specified item is not a gift box.`
            );
          }

          const updatedGifts = account.gifts.filter(
            (e: any) => e.templateId !== req.body.giftBoxItemId
          );
          applyProfileChanges.push({
            changeType: "itemRemoved",
            itemId: req.body.giftBoxItemId,
          });

          await Account.updateOne({ $set: { gifts: updatedGifts } });
        }

        if (Array.isArray(giftBoxItemIds)) {
          const updatedGifts: any[] = [];

          giftBoxItemIds.forEach((entry: any) => {
            if (
              account.gifts[entry] &&
              account.gifts[entry].templateId.startsWith("GiftBox:")
            ) {
              applyProfileChanges.push({
                changeType: "itemRemoved",
                itemId: entry,
              });
            } else {
              account.gifts.forEach((e: any) => {
                if (e.templateId != entry) {
                  updatedGifts.push(e);
                }
              });
            }
          });

          await Account.updateOne({ $set: { gifts: updatedGifts } });
        }

        if (applyProfileChanges.length > 0) {
          await Account.updateOne({
            profilerevision: account.profilerevision + 1,
          });
          await Account.updateOne({
            BaseRevision: account.BaseRevision + 1,
          });
        }

        const updatedAccount = await Account.findOne({ accountId });

        // @ts-ignore
        if (queryRevision !== updatedAccount!.BaseRevision) {
          const commonCore = MCPCommonCore(
            accountId,
            profileId as string,
            true
          );

          applyProfileChanges.push({
            changeType: "fullProfileUpdate",
            profile: commonCore,
          });
        }

        return res.json({
          profileRevision: updatedAccount!.BaseRevision || 0,
          profileId,
          profileChangesBaseRevision: queryRevision,
          profileChanges: applyProfileChanges,
          profileCommandRevision: updatedAccount!.profilerevision || 0,
          serverTime: new Date().toISOString(),
          customResponse: "Thanks for using PlooshFN!",
        });
      } catch (error) {
        const err = error as Error;
        logger.error(`Error removing gift box: ${err.message}`, "MCP");
        res.status(500).json({ error: "Internal Server Error" });
      }
    }
  );

  router.post(
    "/fortnite/api/game/v2/profile/:accountId/*/ClientQuestLogin",
    async (req, res) => {
      try {
        const { rvn, profileId } = req.query;
        const { accountId } = req.params;
        const userAgent = req.headers["user-agent"];
        const season = (userAgent?.split("-")[1]?.split(".")[0] || 2) as string;

        const account = await Account.findOne({ accountId });

        if (!rvn) {
          return res.json({});
        }

        if (!account) {
          return res.status(404).json({
            error: "[ClientQuestLogin]: Account Not Found.",
          });
        }

        if (profileId === "athena" || profileId === "profile0") {
          const currentQuests = quests.Season12;
          const dailyQuests = [
            {
              "templateId": "Quest:AthenaDaily_Outlive_Solo",
              "objectives": [
                "daily_athena_outlive_solo_players"
              ]
            },
            {
              "templateId": "Quest:AthenaDaily_Outlive_Squad",
              "objectives": [
                "daily_athena_outlive_squad_players_v2"
              ]
            },
            {
              "templateId": "Quest:AthenaDaily_Outlive",
              "objectives": [
                "daily_athena_outlive_players_v3"
              ]
            },
            {
              "templateId": "Quest:AthenaDaily_PlayMatches",
              "objectives": [
                "daily_athena_play_matches_v3"
              ]
            },
            {
              "templateId": "Quest:AthenaDaily_Solo_Top25",
              "objectives": [
                "daily_athena_solo_top25_v2"
              ]
            },
            {
              "templateId": "Quest:AthenaDaily_Squad_Top6",
              "objectives": [
                "daily_athena_squad_top6_v2"
              ]
            },
            {
              "templateId": "Quest:AthenaDailyQuest_InteractAmmoCrate",
              "objectives": [
                "athena_daily_loot_ammobox_v2"
              ]
            },
            {
              "templateId": "Quest:AthenaDailyQuest_InteractTreasureChest",
              "objectives": [
                "daily_athena_loot_chest_v2"
              ]
            },
            {
              "templateId": "Quest:AthenaDailyQuest_PlayerElimination",
              "objectives": [
                "athena_daily_kill_players_v2"
              ]
            },
            {
              "templateId": "Quest:AthenaDailyQuest_PlayerEliminationAssaultRifles",
              "objectives": [
                "athena_daily_kill_players_assault_rifles"
              ]
            },
            {
              "templateId": "Quest:AthenaDailyQuest_PlayerEliminationPistols",
              "objectives": [
                "athena_daily_kill_players_pistol_v3"
              ]
            },
            {
              "templateId": "Quest:AthenaDailyQuest_PlayerEliminationShotguns",
              "objectives": [
                "athena_daily_kill_players_shotgun_v2"
              ]
            },
            {
              "templateId": "Quest:AthenaDailyQuest_PlayerEliminationSMGs",
              "objectives": [
                "athena_daily_kill_players_smg_v2"
              ]
            },
            {
              "templateId": "Quest:AthenaDailyQuest_PlayerEliminationSniperRifles",
              "objectives": [
                "athena_daily_kill_players_sniper_v2"
              ]
            }
          ];
          const athenaData = (await Athena(
            accountId,
            profileId,
            false,
            season,
            rvn
          )) as any;
          //console.log(athenaData);
          const currentProfile: IProfile = athenaData.profileChanges[0]?.profile ?? {
            accountId,
            profileId,
            version: "Ploosh",
            rvn: rvn as any,
            items: {},
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            stats: {
              attributes: {},
              templateId: quests.Season12.Quests.find((data) => data.templateId)
                ?.templateId,
            },
            commandRevision: 1,
          };
          //console.log(currentProfile);

          const existingQuests = Object.entries(currentProfile.items ?? {})
            .filter(
              ([, value]) =>
                // @ts-ignore kys
                value.templateId &&
                // @ts-ignore kys
                value.templateId.startsWith(
                  profileId === "athena" ? "Quest:AthenaDaily" : "QuestDaily"
                )
            )
            .map(([itemId, value]) => ({
              itemId,
              value,
            }));

          const uniqueQuests = dailyQuests.filter((data) =>
            existingQuests.every(
              (existing) =>
                // @ts-ignore kys
                existing.value.templateId.toLowerCase() !==
                data.templateId.toLowerCase()
            )
          );
          
          let uuid = generateUUID();
          if (uniqueQuests.length === 0) {
            const randomQuest =
              uniqueQuests[Math.floor(Math.random() * uniqueQuests.length)];

            const newQuest: AccountItem = {
              [uuid]: {
                templateId: randomQuest.templateId,
                attributes: {
                  quest_state: "Active",
                  level: -1,
                  item_seen: false,
                  sent_new_notification: false,
                  xp_reward_scalar: 1,
                  challenge_bundle_id: "",
                  challenge_linked_quest_given: "",
                  challenge_linked_quest_parent: "",
                  playlists: [],
                  bucket: "Ploosh",
                  last_state_change_time: new Date().toISOString(),
                  max_level_bonus: 0,
                  xp: 0,
                  quest_rarity: "uncommon",
                  favorite: false,
                  quest_pool: "",
                  creation_time: new Date().toISOString(),
                  ...Object.fromEntries(
                    randomQuest.objectives.map((data) => [
                      `completion_${data}`,
                      0,
                    ])
                  ),
                },
                quantity: 1,
              },
            };

            const questManager = {
              dailyLoginInterval: new Date().toISOString(),
              questPoolState: {
                dailyLoginInterval: new Date().toISOString(),
              },
              dailyQuestRerolls: 1,
            };

            currentProfile.stats.attributes.quest_manager = questManager;
          }

          return res.json({
            profileRevision: (rvn as any) + 1,
            profileId,
            profileChangesBaseRevision: account.BaseRevision,
            profileChanges: [
              {
                changeType: "fullProfileUpdate",
                profile: currentProfile,
              },
            ],
            notifications: [],
            multiUpdate: [],
            profileCommandRevision: 1,
            serverTime: new Date(),
            responseVersion: 1,
          });
        } else if (
          profileId === "common_core" ||
          profileId === "common_public"
        ) {
          const commonCoreData = await CommonCore(accountId, profileId);
          return res.json(commonCoreData);
        } else {
          const responseData = {
            profileRevision: (rvn as any) + 1,
            profileId,
          };
          res.json(responseData);
        }
      } catch (error) {
        const err = error as Error;
        console.error(`Error updating profile: ${err.message}`);
        res.status(500).json({ error: "Internal Server Error" });
        
        throw err;
      }
    }
  );
}
