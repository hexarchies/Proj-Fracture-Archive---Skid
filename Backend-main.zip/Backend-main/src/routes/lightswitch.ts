import { Router } from "express";
import Account, { IAccount } from "../database/models/Account";
import logger from "../utils/logger";
import jwt, { Jwt, JwtPayload } from "jsonwebtoken";

export default function initRoute(router: Router): void {
  router.get("/lightswitch/api/service/bulk/status", async (req, res) => {
    try {
      const token = req.headers["authorization"]
        ?.toString()
        .split("bearer ")[1];

      if (!token) {
        return res.status(403).json({error: "Forbidden"});
      }

      var data = jwt.decode(token.replace("eg1~", ""));
      var d = data as {"iai": string};
      var accountId = d["iai"];

      const user: IAccount | null = await Account.findOne({
        //$or: [
          //{ "accessToken.0.token": token },
          //{ "clientToken.0.token": token },
        //],
        accountId,
      });

      if (!user) {
        return res.status(403).json({error: "Forbidden"});
      }

      //console.log("s2");

      const serviceStatus = {
        serviceInstanceId: "fortnite",
        status: "UP",
        message: "Servers up.",
        maintenanceUri: "https://discord.gg/StWVWn6a3B",
        overrideCatalogIds: [],
        allowedActions: ["PLAY", "DOWNLOAD"],
        banned: user.banned || false,
        launcherInfoDTO: {},
      };

      return res.status(200).json([serviceStatus]);
    } catch (error) {
      let err = error as Error;
      logger.error(`Error: ${err.message}`, "Lightswitch");
      return res.status(500).send("Internal Server Error");
    }
  });
}
