# PlooshFN Launcher
Credit to zinx for eon launcher because im waiting for mineek to make one for me